library(e1071)
library(xlsx)
library(corrplot)
library(lattice)
library(ggplot2)
library(caret)
library(rpart)
library(rpart.plot)
library(randomForest)
library(ineq)
library(C50)
library(stats)
library(class)
library(glmnet)
library(Matrix)
library(foreach)

t1 = read.xlsx("/Users/AjayKulkarni/Study/Master of Science/Sem 1/CSI 777/data/winequality/new_f/Training.xlsx",1)

t2 = read.xlsx("/Users/AjayKulkarni/Study/Master of Science/Sem 1/CSI 777/data/winequality/new_f/Testing.xlsx",1)

t1$cat[t1$quality < 6] <- "0"
t1$cat[t1$quality >= 6] <- "1"

t2$cat[t2$quality < 6] <- "0"
t2$cat[t2$quality >= 6] <- "1"


write.xlsx(x = t1,file="Training_class_2.xlsx",sheetName = "Sheet1", row.names = FALSE)

write.xlsx(x = t2,file="Testing_class_2.xlsx",sheetName = "Sheet1", row.names = FALSE)


t1 = read.xlsx("/Users/AjayKulkarni/Study/Master of Science/Sem 1/CSI 777/data/winequality/new_f/Training_class_2.xlsx",1)

t2 = read.xlsx("/Users/AjayKulkarni/Study/Master of Science/Sem 1/CSI 777/data/winequality/new_f/Testing_class_2.xlsx",1)


# C5.0 2 var Classification (75%) all(76.38%) 6 variables(72.77%)

#x_data = t1[,c(2,3,7,9,10,11,12)]	# Model 1
#y_data = t2[,c(2,3,7,9,10,11,12)]	# Model 1

x_data = t1[,c(2,8,10,11,12)]	# Model 2
y_data = t2[,c(2,8,10,11,12)]	# Model 2

model <- C5.0(quality~.,data=x_data)
summary(model)
res <- predict(object=model,newdata=y_data,type="class")
table(res,t2$quality)


#SVM 2 var classification (80.29%) 6variables(75%) all(76.94%)

model <- svm(quality ~ fixed.acidity + volatile.acidity + citric.acid + residual.sugar + chlorides + free.sulfur.dioxide + total.sulfur.dioxide + density + pH + sulphates + alcohol, data = t1)

model <- svm(quality ~ alcohol + sulphates + volatile.acidity + density,data=t1)

model <- svm(quality ~ alcohol + sulphates + volatile.acidity + pH + citric.acid + total.sulfur.dioxide,data=t1)

results <- predict(object=model, newdata = t2,type="class")
table(results,t2$quality)



#CART 2 var Classification (75.00%) all(75.00%) 6variables(62.22%)

model <- rpart(quality ~ fixed.acidity + volatile.acidity + citric.acid + residual.sugar + chlorides + free.sulfur.dioxide + total.sulfur.dioxide + density + pH + sulphates + alcohol, data = t1)

model <- rpart(quality ~ alcohol + sulphates + volatile.acidity + density,data=t1)

res <- predict(object=model,newdata=t2,type="class")
table(res,t2$quality)








